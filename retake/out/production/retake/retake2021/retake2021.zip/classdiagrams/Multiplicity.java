package retake2021.classdiagrams;

public enum Multiplicity {
    ZERO_TO_ONE,
    ONE,
    ZERO_TO_MANY
}
